#ifndef _ASERCOM
#define _ASERCOM


void run_asercom();

#endif
