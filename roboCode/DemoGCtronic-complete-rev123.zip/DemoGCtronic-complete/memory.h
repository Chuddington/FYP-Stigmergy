#ifndef _MEMORY_
#define _MEMORY_

// MEMORY 
#define DEFAULT_WIDTH 48 // => 7.5% of max width //52
#define DEFAULT_HEIGHT 36 // => 7.5% of max height //39
#define BUFFER_SIZE (DEFAULT_WIDTH*DEFAULT_HEIGHT*2)

#endif /* _MEMORY_ */
