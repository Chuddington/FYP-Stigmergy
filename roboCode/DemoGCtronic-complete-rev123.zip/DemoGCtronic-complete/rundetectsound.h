#ifndef _LOCATES
#define _LOCATES

void run_detectsound();

#endif
