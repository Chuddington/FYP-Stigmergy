#ifndef _TRANSLATOR
#define _TRANSLATOR


void run_translatorI2C();

#endif
