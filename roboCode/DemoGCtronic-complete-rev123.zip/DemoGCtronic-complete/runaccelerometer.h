
int run_accelerometer();
